# Plopsaland Deutschland — GenAI Prompt Pack
**Campagne: Die erfrischenden 7 · v1 · 30-07-2026**
Doelmodellen: **Nano Banana Pro** (primair) en **GPT Image 2** (alternatief). Werkwijze: **clean plate** — AI genereert alleen fotografie; logo, headline, badge en CTA komen als vectorlaag uit InDesign/Figma.

---

## 1. Audit huidige set (samenvatting)

| # | Asset | Status | Belangrijkste problemen |
|---|-------|--------|------------------------|
| 7-1 | Story, rapids | Echt beeld | Referentie-baseline. Scriptlogo-variant. |
| 7-2 | 1:1, waterplein | Echt beeld | Ander logo-lockup (Plopsa**LAND**) dan 7-1 binnen dezelfde campagne. |
| 7-3 | 16:9, glijbaan | AI-bewerkt | Logo gecorrumpeerd: **"Ploppsaland"** (dubbele p). |
| 7-4 | Story, Wickie Splash | AI | **2×2-zitopstelling terwijl de echte boot single file is**; verkeerde bootgeometrie; "Abk**ù**hlung" i.p.v. "Abkühlung"; nagetekend logo; blauw object dat als geparkeerde auto leest; boot drijft in schuim zonder zichtbare goot; warme AI-gloed die botst met de campagnefotografie. |
| 7-5 | 1:1, Wickie Splash | AI | Zelfde gezin, **andere kledingkleuren** dan 7-4 (moeder roze→paars, vader blauw→groen); sprookjesachtige torens die niet bij de echte parkarchitectuur horen; opnieuw 2×2; badge- en layoutsysteem wijkt af van 7-4. |
| 7-6 | Story, glijbaan | AI | Decor met reuzenbloemen/-fruit dat met geen bekende parkzone matcht; kinderen uit 7-3 met gezichtsdrift; derde badge-ontwerp; CTA wijkt af ("Jetzt entdecken"). |
| 7-7 | Story, waterplein | Echt beeld | Vierde CTA ("Besuch planen"); weer een andere badge- en logoweergave. |
| 7-8 | Story, buisglijbaan | AI | Roze sprookjeskasteel dat nergens in het park lijkt te bestaan; roze/gele glijbaankleuren die afwijken van de echte blauw/gele toestellen; vijfde badge-ontwerp. |
| 7-9 | Story, collage | Mix | Clownsfiguur die geen herkenbaar officieel parkkarakter is (IP-risico); verzonnen glijbaancomplex; aquarel-spatten naast de vlakke vector-druppels van de rest van de set; vijfde CTA ("Park erleben"). |

**Systemische oorzaken:** (1) typografie en logo worden mee gegenereerd, (2) geen referentieprotocol voor attracties, (3) geen bevroren cast/wardrobe over declinaties heen, (4) geen check-in vóór oplevering. Het promptpack en de skill lossen die vier op.

**Let op bij echte referentiefoto's:** op ride-vehicles staat nog legacy **"Holiday Park"**-belettering (o.a. Wickie Splash-boot "14"). Nooit laten meegenereren of ongecorrigeerd publiceren in nieuwe-merk-uitingen.

---

## 2. Werkwijze per asset (samengevat)

```
PASS 0  READ-BACK   → model beschrijft de referentie; team corrigeert vóór er iets gegenereerd wordt
PASS 1  SCENE LOCK  → één master: attractie + omgeving + stijl, correcte configuratie, geen tekst
        ✋ GATE A    → parkrealiteit checken (zitopstelling, voertuig, omgeving)
PASS 2  ELEMENTEN   → cast/emotie/splash bijsturen in multi-turn edits; attractie blijft bevroren
        ✋ GATE B    → cast-lock + artefacten checken
PASS 3  DECLINATIES → formaten/momenten afleiden van de goedgekeurde master
        ✋ GATE C    → volledige eval-checklist; daarna pas naar design voor type/logo-overlay
```

---

## 3. De prompts

### 3.0 Character lock (eenmalig vastleggen, daarna letterlijk hergebruiken)

```
THE FAMILY (paste verbatim into every asset of this campaign):
MOTHER — woman in her late 30s, dark-blonde hair in a low ponytail, light-pink T-shirt, denim shorts.
FATHER — man in his early 40s, short brown hair, light stubble, royal-blue T-shirt, beige shorts.
DAUGHTER — girl around 8, long light-brown hair, soft-pink T-shirt.
SON — boy around 10, short dark-blond hair, cobalt-blue T-shirt.
All four are visibly soaked, laughing with open mouths, arms raised.
```

> Eén keer definiëren met het team (of vervangen door character-referentiebeelden van een echte shoot), daarna bevriezen. Elke declinatie hergebruikt dit blok én de goedgekeurde vorige generatie als character reference.

### 3.1 PASS 0 — Read-back van de referentie (geen generatie)

```
Before generating anything: study the attached reference image of the Wickie Splash log flume at Plopsaland Deutschland. Report back as a numbered list: (1) the boat — shape, materials, construction details, and exactly how riders are seated (how many, side by side or single file); (2) the water channel and immediate surroundings; (3) camera position and framing; (4) lighting and color character. If something is not visible in the reference, write "not visible" — do not guess. Do not generate an image yet.
```

> **Check-in:** klopt de read-back niet met de werkelijkheid, corrigeer in tekst ("Correction: riders sit strictly single file, one behind the other") vóór Pass 1. Dit is het moment waarop de 2×2-fout van 7-4 wordt afgevangen.

### 3.2 PASS 1 — Scene lock · Wickie Splash hero, 9:16 (Nano Banana Pro)

```
REFERENCE IMAGE ROLES:
— Image 1 (website screenshot of the log flume boat coming down the chute): OBJECT + ENVIRONMENT REFERENCE. Reproduce this exact ride: a barrel-style log flume boat built from vertical dark-wood staves with metal bands, one seat wide, riding in a narrow water trough. Ignore the people, the lettering and the number on this boat — render all boat surfaces as plain weathered wood with no markings.
— Image 2 (campaign photo of the round raft on the rapids river): STYLE REFERENCE ONLY. Match the photography: bright midday summer sun, crisp directional light, natural saturated color, documentary energy, water droplets frozen sharp in mid-air. DO NOT copy this ride, its raft or its composition.

NEW SCENE:
Photorealistic vertical 9:16 photograph at Plopsaland Deutschland. The barrel boat from Image 1 has just hit the bottom of the final drop of the log flume. Four riders sit strictly single file, one behind the other — a girl of about 8 in front, then a boy of about 10, then their mother, then their father at the rear. The boat is one seat wide; nobody sits side by side. A bow wave bursts up and outward around the front of the boat, backlit spray filling the air; the wet chute is visible behind them; dense green summer trees surround the flume. No buildings, no vehicles, no other people.
Camera: frontal, slightly below the riders' eye level, medium telephoto compression, boat centered, motion frozen.
Composition reserves clean space: the top 30% is calm background (spray mist and soft greenery, no subjects) for a headline overlay, and the bottom 12% is simple foam and water for a CTA overlay.
Strictly no text anywhere in the image: no letters, numbers, logos or signage on the boat, clothing or background.
2K resolution.
```

### 3.3 PASS 2 — Elementen toevoegen/bijsturen (multi-turn na Pass 1)

```
Keep the boat, the water channel, the environment and the composition exactly as they are. Only replace the four riders with THE FAMILY, seated in the same single-file order: [paste THE FAMILY block]. Their expressions are mid-laugh, eyes open where visible, hands and fingers natural. Change nothing else in the image.
```

```
Keep everything exactly as it is. Only intensify the splash: raise the bow wave slightly higher on both sides and add fine backlit mist above the boat, without covering any of the four faces. Do not render any text.
```

### 3.4 PASS 3 — Formaat-declinaties van de goedgekeurde master

```
Treat the attached approved image as the untouched master. Recompose to a square 1:1 frame: keep the boat, riders, splash, lighting and grade identical, extend the scene naturally on the left and right with more greenery and spray, and reserve the top 25% as calm background for a headline overlay. Do not redraw or restyle the boat or the riders. No text anywhere.
```

```
Treat the attached approved image as the untouched master. Recompose to a wide 16:9 frame: the boat and riders stay identical and move to the right half of the frame; extend the scene on the left with the wet chute and greenery, keeping that left 45% calm and low-detail for headline and CTA overlays. Do not redraw or restyle the boat or the riders. No text anywhere.
```

### 3.5 Declinatie vanuit een échte foto (voorkeursroute als er fotografie bestaat)

```
The attached photograph is the untouched master. Extend the canvas upward and downward to a 9:16 frame, continuing only the existing scene — same water, same spray, same greenery, same light direction, same grain. Do not alter a single pixel inside the original photograph, do not add people, objects or structures, and render no text anywhere.
```

```
In the attached photograph, remove the lettering on the boat's bow band and rebuild the plain weathered wood behind it. Change nothing else — riders, water, light and background stay exactly as shot.
```

### 3.6 GPT Image 2 — zelfde prompts, andere instellingen

- Zet de attractie-screenshot als **eerste** input-image en gebruik `input_fidelity: high` (eerste 5 beelden behouden detail).
- Maten: 9:16 bestaat niet native → genereer `1024x1536` en crop; 1:1 = `1024x1024`; 16:9 ≈ `1536x1024`.
- Itereren op `quality: medium`, finals op `high`. Multi-turn via de Responses API (`previous_response_id`).

---

## 4. Declinatie-matrix (voor Xavier's varianten-verzoeken)

Varieer over **assen**, niet cosmetisch. Cast, fotografiestijl en designsysteem blijven bevroren.

| As | Waarden |
|----|---------|
| Attractie | alleen bevestigde leden van "Die erfrischenden 7", elk met eigen referentiebeeld |
| Formaat | 9:16 · 4:5 · 1:1 · 16:9 (vaste negative-space-zones per formaat) |
| Moment | splash-impact · bovenaan de drop (anticipatie) · samen lachend na afloop |
| Bezetting | gezin · tieners · kinderen (per doelgroepsegment, cast per segment bevroren) |

**Zwak/sterk-test:** zouden twee verschillende mensen verschillend reageren op twee varianten? Nee → één van de twee is cosmetisch en vervalt.

---

## 5. Check-in vóór oplevering

Draai elke asset door de eval-checklist in de skill (`references/eval-checklist.md`): parkrealiteit → merk → typografie (na overlay) → mensen → fysica/artefacten → setconsistentie. Harde afkeur bij: verkeerde ride-configuratie, verzonnen parkelementen, gegenereerd logo/tekst, legacy "Holiday Park"-branding, niet-officiële karakters.
